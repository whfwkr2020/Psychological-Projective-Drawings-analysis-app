package com.example.team2020;

public class MyPage12 {
}
